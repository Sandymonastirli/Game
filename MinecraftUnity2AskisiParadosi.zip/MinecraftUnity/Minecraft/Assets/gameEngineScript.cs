﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Random = UnityEngine.Random;

public class gameEngineScript : MonoBehaviour
{

    public Transform bCube;
    public Transform rCube;
    public Transform yCube;
    public Transform gCube;
    public Transform tCube;
    public Transform mCube;
    public Transform spotLight;
    public InputField input;

    public int N;
    public static int GridSize;
    public static bool Started;
    private GameObject tCanvas;
    void Awake()
    {
        Debug.Log("Awake gameEngineScript");
        tCanvas = GameObject.Find("Canvas");
        input = GameObject.Find("InputField").GetComponent<InputField>();
        input.onEndEdit.AddListener(GetInput);
        input.Select();
        input.ActivateInputField();
        //var o = GameObject.Find("InputField");
        //o.SetActive(false);
    }

    // Use this for initialization
    void Start()
    {
        Debug.Log("Start gameEngineScript");
        //N = 13;
        //CreateGrid(13);
        //AddDemoWall();
        //createLights();
    }

    public void GetInput(string arg0)
    {
        Debug.Log("User entered " + arg0);
        var o = GameObject.Find("InputField");
        o.SetActive(false);
        N = int.Parse(arg0);
        CreateGrid(N);
        //AddDemoWall();
        createLights();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    Transform getCube(int i)
    {
        Transform cube = gCube;//default green
        if (i == 1)
        {
            cube = bCube;
        }
        if (i == 2)
        {
            cube = rCube;
        }
        if (i == 3)
        {
            cube = yCube;
        }
        if (i == 4)
        {
            cube = gCube;
        }
        if (i == 5)
        {
            cube = tCube;
        }

        return cube;
    }

    private void CreateGrid(int size)
    {
        N = size;
        gameEngineScript.GridSize = N;
        double r = N / 2.0f;
        int centerCubeNumber = (int)Math.Round(r);
        for (int i = 0; i < N; i++)
        {
            int cubeType = Random.Range(1, 6);
            Vector3 position = new Vector3(i, 0, 0);
            Transform cube = getCube(cubeType);
            Instantiate(cube, position, bCube.rotation);
            for (int j = 1; j < N; j++)
            {
                if (centerCubeNumber == i && centerCubeNumber == j)
                {
                    //O kentrikos kivos einai xrwmatos magenta
                    position = new Vector3(i, 0, j);
                    Instantiate(mCube, position, mCube.rotation);
                }
                else
                {
                    cubeType = Random.Range(1, 6);
                    position = new Vector3(i, 0, j);
                    cube = getCube(cubeType);
                    Instantiate(cube, position, bCube.rotation);
                }
            }
        }

        //Set player position
        var camera = GameObject.Find("FPSController").GetComponent<Transform>();
        camera.position = new Vector3(centerCubeNumber, 1.6f, centerCubeNumber);
        FirstPersonController.playerHeight = (int)Math.Abs(camera.position.y);
        Started = true;
    }

    private void AddDemoWall()
    {
        for (int i = 0; i < N; i++)
        {
            int cubeType = Random.Range(1, 6);
            Vector3 position = new Vector3(i, 1.5f, N-1);
            Transform cube = getCube(cubeType);
            Instantiate(cube, position, bCube.rotation);
        }
    }

    private void createLights()
    {
        var light1 = Instantiate(spotLight, new Vector3(N, N, 0), new Quaternion(60, -45, 0, 1));
        light1.transform.localEulerAngles = new Vector3(60, -45, 0);
        var light2 = Instantiate(spotLight, new Vector3(0, N, N), new Quaternion(120, -45, 0, 1));
        light2.transform.localEulerAngles = new Vector3(120, -45, 0);
    }
}
