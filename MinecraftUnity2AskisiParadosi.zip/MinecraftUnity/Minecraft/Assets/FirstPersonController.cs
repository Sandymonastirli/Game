﻿using System.Collections;
using System.Collections.Generic;
using Assets;
using UnityEngine;
using UnityEngine.UI;
using UnityStandardAssets.CrossPlatformInput;
using UnityStandardAssets.Utility;

[RequireComponent(typeof(CharacterController))]
[RequireComponent(typeof(AudioSource))]
public class FirstPersonController : MonoBehaviour
{
    [SerializeField] private bool m_IsWalking;
    [SerializeField] private float m_WalkSpeed;
    [SerializeField] private float m_RunSpeed;
    [SerializeField] [Range(0f, 1f)] private float m_RunstepLenghten;
    [SerializeField] private float m_JumpSpeed;
    [SerializeField] private float m_StickToGroundForce;
    [SerializeField] private float m_GravityMultiplier;
    [SerializeField] private MouseLook m_MouseLook;
    [SerializeField] private bool m_UseFovKick;
    [SerializeField] private FOVKick m_FovKick = new FOVKick();
    [SerializeField] private bool m_UseHeadBob;
    [SerializeField] private CurveControlledBob m_HeadBob = new CurveControlledBob();
    [SerializeField] private LerpControlledBob m_JumpBob = new LerpControlledBob();
    [SerializeField] private float m_StepInterval;
    [SerializeField] private AudioClip[] m_FootstepSounds;    // an array of footstep sounds that will be randomly selected from.
    [SerializeField] private AudioClip m_JumpSound;           // the sound played when character leaves the ground.
    [SerializeField] private AudioClip m_LandSound;           // the sound played when character touches back on ground.
    [SerializeField] private KeyCode takeCubeCode;
    [SerializeField] private KeyCode placeCubeCode;
    [SerializeField] private KeyCode placeCylinderCode;
    [SerializeField] private Text ScoreText;
    [SerializeField] private Transform blueCube;
    [SerializeField] private Transform redCube;
    [SerializeField] private Transform yellowCube;
    [SerializeField] private Transform greenCube;
    [SerializeField] private Transform cylinderBlock;

    private Camera m_Camera;
    private bool m_Jump;
    private float m_YRotation;
    private Vector2 m_Input;
    private Vector3 m_MoveDir = Vector3.zero;
    private CharacterController m_CharacterController;
    private CollisionFlags m_CollisionFlags;
    private bool m_PreviouslyGrounded;
    private Vector3 m_OriginalCameraPosition;
    private float m_StepCycle;
    private float m_NextStep;
    private bool m_Jumping;
    private AudioSource m_AudioSource;
    private int points;
    private int lifes;
    private int cubes;
    private int cylinders;
    public static int playerHeight;
    private float fallDistance;
    private bool m_falling;

    void Awake()
    {

    }

    // Use this for initialization
    private void Start()
    {
        Debug.Log("Start FirstPersonController");
        points = 100;
        lifes = 4;
        cubes = 0;
        cylinders = 0;
        m_CharacterController = GetComponent<CharacterController>();
        m_Camera = Camera.main;
        m_OriginalCameraPosition = m_Camera.transform.localPosition;
        m_FovKick.Setup(m_Camera);
        m_HeadBob.Setup(m_Camera, m_StepInterval);
        m_StepCycle = 0f;
        m_NextStep = m_StepCycle / 2f;
        m_Jumping = false;
        m_AudioSource = GetComponent<AudioSource>();
        m_MouseLook.Init(transform, m_Camera.transform);
    }

    // Update is called once per frame
    private void Update()
    {
        //Elegxos tou paikti gia na min vgei ektos plaisiou
        if (transform.position.x < 0) transform.position = new Vector3(0, transform.position.y, transform.position.z);
        if (transform.position.x > gameEngineScript.GridSize - 1) transform.position = new Vector3(gameEngineScript.GridSize - 1, transform.position.y, transform.position.z);
        if (transform.position.z < 0) transform.position = new Vector3(transform.position.x, transform.position.y, 0);
        if (transform.position.z > gameEngineScript.GridSize - 1) transform.position = new Vector3(transform.position.x, transform.position.y, gameEngineScript.GridSize - 1);

        RotateView();
        int currentHeight = (int)Mathf.Abs(transform.position.y);
        // the jump state needs to read here to make sure it is not missed
        if (!m_Jump)
        {
            m_Jump = CrossPlatformInputManager.GetButtonDown("Jump");
        }

        //elegxos an o paiktis peftei sto keno
        if (transform.position.y < 0 && gameEngineScript.Started)
        {
            lifes -= 1;
            var center = Mathf.Round(gameEngineScript.GridSize / 2.0f);
            m_CharacterController.transform.position = new Vector3(center, 2.0f, center);
        }
        if (!m_PreviouslyGrounded && m_CharacterController.isGrounded)
        {
            //Elegxos an o paiktis epese epipedo
            fallDistance = currentHeight - playerHeight;
            StartCoroutine(m_JumpBob.DoBobCycle());
            PlayLandingSound();
            m_MoveDir.y = 0f;
            m_Jumping = false;
            //reset jump speed
            m_JumpSpeed = 6.0f;
            if (currentHeight > playerHeight)
            {
                points += 10;//o paiktis pairnei 10 pontous giati pidikse panw se neo epipedo
            }

            //Debug.Log("Current height: " + currentHeight + " Player Height:" + playerHeight + " FallDistance:" + fallDistance);
            //elegxos an o paiktis exei pesei parapanw apo 1 epipeda
            if (fallDistance < -1)
            {
                points -= (int)(Mathf.Abs(fallDistance) - 1) * 10;
                if (points < 0)
                {
                    lifes--;
                    points = 0;
                }
                fallDistance = 0;
            }
            else fallDistance = 0;
            playerHeight = currentHeight;
            //elegxos an o paiktis eftase sto teleutaio epipedo
            if (gameEngineScript.GridSize != 0 && playerHeight == gameEngineScript.GridSize)
            {
                lifes++;
                points += 100;
            }
        }
        if (!m_CharacterController.isGrounded && !m_Jumping && m_PreviouslyGrounded)
        {
            m_MoveDir.y = 0f;
        }

        m_PreviouslyGrounded = m_CharacterController.isGrounded;

        //an patithike to pliktro P (pairnei kivo)
        if (Input.GetKeyDown(takeCubeCode))
        {
            //check if object is raycasted
            RaycastHit hit;
            //Theloume na kanoume raycast ekei pou koitaei i camera
            Ray ray = m_Camera.ScreenPointToRay(Input.mousePosition);
            if (Physics.Raycast(ray, out hit, 1.0f))
            {
                var c = getCube(hit.transform);
                if (c > 0)
                {
                    points -= 5;
                    cubes += c;
                }
            }
        }

        //an patithike to pliktro B (topothetei kivo)
        if (Input.GetKeyDown(placeCubeCode))
        {
            if (cubes > 0)
            {
                int random = Random.Range(1, 5);
                Debug.Log("Random " + random);
                Transform cubeToInstantiate = blueCube;
                if (random == 1)
                {
                    cubeToInstantiate = blueCube;
                }
                else if (random == 2)
                {
                    cubeToInstantiate = redCube;
                }
                else if (random == 3)
                {
                    cubeToInstantiate = yellowCube;
                }
                else if (random == 4)
                {
                    cubeToInstantiate = greenCube;
                }
                RaycastHit hit;
                if (Physics.Raycast(transform.position,
                    transform.TransformDirection(Vector3.forward), out hit, 1.0f))
                {
                    Debug.Log("Place over");
                    Instantiate(cubeToInstantiate, new Vector3(hit.transform.position.x,
                            hit.transform.position.y + 1, hit.transform.position.z),
                        cubeToInstantiate.rotation);
                }
                else
                {
                    Debug.Log("Place same level");
                    Instantiate(cubeToInstantiate, transform.position + transform.forward * 1.0f,
                        cubeToInstantiate.rotation);
                }
                cubes -= 1;
                points += 10;
            }
        }

        //an patithike to pliktro C (topothetei kilindro efoson exei apothema)
        if (Input.GetKeyDown(placeCylinderCode) && cylinders > 0)
        {
            RaycastHit hit;
            if (Physics.Raycast(transform.position,
                transform.TransformDirection(Vector3.forward), out hit, 1.0f))
            {
                Debug.Log("Place over");
                Instantiate(cylinderBlock, new Vector3(hit.transform.position.x,
                        hit.transform.position.y + 1, hit.transform.position.z),
                    cylinderBlock.rotation);
            }
            else
            {
                Debug.Log("Place same level");
                Instantiate(cylinderBlock, transform.position + transform.forward * 1.0f,
                    cylinderBlock.rotation);
            }

            cylinders -= 1;
        }

        UpdateStatusText();
    }

    private int getCube(Transform cube)
    {
        if (cube == null) return 0;

        var cubeRenderer = cube.GetComponent<Renderer>();
        Debug.Log(cubeRenderer.material.name);
        string objectName = cubeRenderer.material.name;

        //an o kivos einai kokkinos kane ton kitrino
        if (objectName == "redCubeMaterial (Instance)")
        {
            var yellowMaterial = (Material)Resources.Load("Materials/yellowCubeMaterial", typeof(Material));
            cubeRenderer.sharedMaterial = yellowMaterial;
        }
        //an o kivos einai prasinos kane ton kokkino
        else if (objectName == "greenCubeMaterial (Instance)")
        {
            var redMaterial = (Material)Resources.Load("Materials/redCubeMaterial", typeof(Material));
            cubeRenderer.sharedMaterial = redMaterial;
        }
        //an o kivos einai mple min kaneis tipota
        else if (objectName == "blueCubeMaterial (Instance)")
        {
            //destroy??
            return 0;
        }
        //an o kivos einai kitrinos kane ton mple
        else if (objectName == "yellowCubeMaterial (Instance)")
        {
            var blueMaterial = (Material)Resources.Load("Materials/blueCubeMaterial", typeof(Material));
            cubeRenderer.sharedMaterial = blueMaterial;
        }
        //an o kivos einai thalasis katestrepse ton k pare ena kilindro
        else if (objectName == "tealCubeMaterial (Instance)")
        {
            cylinders += 1;
            Destroy(cube.gameObject);
            return 0;
        }
        //an o kivos einai mwv min kaneis tipota
        else if (objectName == "magentaCubeMaterial (Instance)")
        {
            return 0;
        }

        return 1;
    }

    private void UpdateStatusText()
    {
        ScoreText.text = "Πόντοι: " + points + "\nΖωές:" + lifes + "\nΑπόθεμα κύβων:" + cubes + "\nΑπόθεμα κύλινδρων:" + cylinders + "\nΕπίπεδο:" + playerHeight;
    }


    private void PlayLandingSound()
    {
        m_AudioSource.clip = m_LandSound;
        m_AudioSource.Play();
        m_NextStep = m_StepCycle + .5f;
    }


    private void FixedUpdate()
    {
        float speed;
        GetInput(out speed);
        // always move along the camera forward as it is the direction that it being aimed at
        Vector3 desiredMove = transform.forward * m_Input.y + transform.right * m_Input.x;

        // get a normal for the surface that is being touched to move along it
        RaycastHit hitInfo;
        Physics.SphereCast(transform.position, m_CharacterController.radius, Vector3.down, out hitInfo,
                           m_CharacterController.height / 2f, Physics.AllLayers, QueryTriggerInteraction.Ignore);
        desiredMove = Vector3.ProjectOnPlane(desiredMove, hitInfo.normal).normalized;

        m_MoveDir.x = desiredMove.x * speed;
        m_MoveDir.z = desiredMove.z * speed;


        if (m_CharacterController.isGrounded)
        {
            m_MoveDir.y = -m_StickToGroundForce;

            if (m_Jump)
            {
                //An o paiktis einai mprosta se kilindro tote megalwse to ipsos tou pidimatos gia na mporesei na pidiksei panw ston kilindro
                RaycastHit hit;
                if (Physics.Raycast(transform.position,
                    transform.TransformDirection(Vector3.forward), out hit, 1.0f))
                {
                    if (hit.transform.name == "Cylinder(Clone)")
                        m_JumpSpeed = 10.0f;
                }
                m_MoveDir.y = m_JumpSpeed;
                m_Jump = false;
                m_Jumping = true;
            }
        }
        else
        {
            m_MoveDir += Physics.gravity * m_GravityMultiplier * Time.fixedDeltaTime;
        }
        m_CollisionFlags = m_CharacterController.Move(m_MoveDir * Time.fixedDeltaTime);

        UpdateCameraPosition(speed);

        m_MouseLook.UpdateCursorLock();
    }
    
    private void UpdateCameraPosition(float speed)
    {
        Vector3 newCameraPosition;
        if (!m_UseHeadBob)
        {
            return;
        }
        if (m_CharacterController.velocity.magnitude > 0 && m_CharacterController.isGrounded)
        {
            m_Camera.transform.localPosition =
                m_HeadBob.DoHeadBob(m_CharacterController.velocity.magnitude +
                                  (speed * (m_IsWalking ? 1f : m_RunstepLenghten)));
            newCameraPosition = m_Camera.transform.localPosition;
            newCameraPosition.y = m_Camera.transform.localPosition.y - m_JumpBob.Offset();
        }
        else
        {
            newCameraPosition = m_Camera.transform.localPosition;
            newCameraPosition.y = m_OriginalCameraPosition.y - m_JumpBob.Offset();
        }
        m_Camera.transform.localPosition = newCameraPosition;
    }


    private void GetInput(out float speed)
    {
        // Read input
        float horizontal = CrossPlatformInputManager.GetAxis("Horizontal");
        float vertical = CrossPlatformInputManager.GetAxis("Vertical");

        bool waswalking = m_IsWalking;

#if !MOBILE_INPUT
        // On standalone builds, walk/run speed is modified by a key press.
        // keep track of whether or not the character is walking or running
        m_IsWalking = !Input.GetKey(KeyCode.LeftShift);
#endif
        // set the desired speed to be walking or running
        speed = m_IsWalking ? m_WalkSpeed : m_RunSpeed;
        m_Input = new Vector2(horizontal, vertical);

        // normalize input if it exceeds 1 in combined length:
        if (m_Input.sqrMagnitude > 1)
        {
            m_Input.Normalize();
        }

        // handle speed change to give an fov kick
        // only if the player is going to a run, is running and the fovkick is to be used
        if (m_IsWalking != waswalking && m_UseFovKick && m_CharacterController.velocity.sqrMagnitude > 0)
        {
            StopAllCoroutines();
            StartCoroutine(!m_IsWalking ? m_FovKick.FOVKickUp() : m_FovKick.FOVKickDown());
        }
    }


    private void RotateView()
    {
        m_MouseLook.LookRotation(transform, m_Camera.transform);
    }


    private void OnControllerColliderHit(ControllerColliderHit hit)
    {
        //Debug.Log("OnColliderHit");
        Rigidbody body = hit.collider.attachedRigidbody;
        //dont move the rigidbody if the character is on top of it
        if (m_CollisionFlags == CollisionFlags.Below)
        {
            return;
        }

        if (body == null || body.isKinematic)
        {
            return;
        }
        body.AddForceAtPosition(m_CharacterController.velocity * 0.1f, hit.point, ForceMode.Impulse);
    }
}
