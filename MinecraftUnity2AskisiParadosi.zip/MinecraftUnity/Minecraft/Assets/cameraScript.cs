﻿using System.Collections;
using System.Collections.Generic;
using System.Runtime.Remoting.Messaging;
using UnityEngine;
using UnityEngine.UI;

public class cameraScript : MonoBehaviour
{
    public KeyCode forward;
    public KeyCode backward;
    public KeyCode left;
    public KeyCode right;
    public KeyCode takeCube;
    public KeyCode placeCube;
    public KeyCode placeCylinder;
    public Transform blueCube;
    public Transform redCube;
    public Transform yellowCube;
    public Transform greenCube;

    public Text ScoreText;
    private int points;
    private int lifes;
    private int cubes;
    private int cylinders;

    void Awake()
    {
        points = 100;
        lifes = 4;
        cubes = 0;
        cylinders = 0;
    }

    // Use this for initialization
    void Start()
    {
        ScoreText.text = "Πόντοι: " + points + " Ζωές:" + lifes + " Απόθεμα κύβων:" + cubes + " Απόθεμα κύλινδρων:" + cylinders;
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(takeCube))
        {
            //check if object is raycasted
            RaycastHit hit;
            if (Physics.Raycast(transform.position,
                transform.TransformDirection(Vector3.forward), out hit, 1.0f))
            {
                points -= 5;
                string objectName = hit.transform.name;
                if (objectName == "redCube(Clone)")
                {
                    cubes += 2;
                }
                else if (objectName == "greenCube(Clone)")
                {
                    cubes += 3;
                }
                else if (objectName == "blueCube(Clone)")
                {
                    cubes += 0;
                }
                else if (objectName == "yellowCube(Clone)")
                {
                    cubes += 1;
                }
                else if (objectName == "tealCube(Clone)")
                {
                    cubes += 0;
                    cylinders += 1;
                }
                else if (objectName == "magentaCube(Clone)")
                {
                    cubes += 0;
                }
            }
        }

        if (Input.GetKeyDown(placeCube))
        {
            if (cubes > 0)
            {
                int random = Random.Range(1, 5);
                Debug.Log("Random " + random);
                Transform cubeToInstantiate = blueCube;
                if (random == 1)
                {
                    cubeToInstantiate = blueCube;
                }
                else if (random == 2)
                {
                    cubeToInstantiate = redCube;
                }
                else if (random == 3)
                {
                    cubeToInstantiate = yellowCube;
                }
                else if (random == 4)
                {
                    cubeToInstantiate = greenCube;
                }
                RaycastHit hit;
                if (Physics.Raycast(transform.position,
                    transform.TransformDirection(Vector3.forward), out hit, 1.0f))
                {
                    Debug.Log("Place over");
                    Instantiate(cubeToInstantiate, new Vector3(hit.transform.position.x,
                            hit.transform.position.y + 1, hit.transform.position.z),
                        cubeToInstantiate.rotation);
                }
                else
                {
                    Debug.Log("Place same level");
                    Instantiate(cubeToInstantiate, transform.position + transform.forward * 1.0f,
                        cubeToInstantiate.rotation);
                }
                cubes -= 1;
                points += 10;
            }
        }
        ScoreText.text = "Πόντοι: " + points + " Ζωές:" + lifes + " Απόθεμα κύβων:" + cubes + " Απόθεμα κύλινδρων:" + cylinders;

        if (Input.GetKeyDown(forward))
        {
            GetComponent<Rigidbody>().AddRelativeForce(0, 0, 100);

            if (gameObject.transform.position.z > 12)
            {
                Debug.Log("over z");
                GetComponent<Rigidbody>().velocity = new Vector3(0, 0, 0);
            }
        }
        if (Input.GetKeyUp(forward))
        {
            GetComponent<Rigidbody>().velocity = new Vector3(0, 0, 0);

        }
        if (Input.GetKeyDown(backward))
        {
            GetComponent<Rigidbody>().AddRelativeForce(0, 0, -100);
        }
        if (Input.GetKeyUp(backward))
        {
            GetComponent<Rigidbody>().velocity = new Vector3(0, 0, 0);
        }

        if (Input.GetKeyDown(left))
        {
            GetComponent<Rigidbody>().angularVelocity = new Vector3(0, -3, 0);
        }
        if (Input.GetKeyDown(right))
        {
            GetComponent<Rigidbody>().angularVelocity = new Vector3(0, 3, 0);
        }

        if (Input.GetKeyUp(left))
        {
            GetComponent<Rigidbody>().angularVelocity = new Vector3(0, 0, 0);
        }
        if (Input.GetKeyUp(right))
        {
            GetComponent<Rigidbody>().angularVelocity = new Vector3(0, 0, 0);
        }
    }
}
